import React from 'react';
export default function App() {
    return (
        <div>Good luck building HifzApp UI using React</div>
    )
}